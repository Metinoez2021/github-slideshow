# Microgrid Simulator
Python Framework um ein nicht kooperatives, payoff basiertes Spiel zwischen Microgrids am Day Ahead Markt zu simulieren.

# Ausführen
In der main.py die gewünschte Game Config auswählen, mit python3 -i main.py erhält man nach dem Ende der Simulation eine python shell mit der man alle Objecte inspizieren kann und sich nach belieben Plots generieren und speichern kann.

# Setup unter Linux:
Python Requirements installieren:
pip3 install -r python_requirements.txt

# Setup unter Windows:
Ein erster anhaltspunkt ist die win_requirements.txt Datei. Wichtig ist, dass Cpp installiert ist, damit Quadprog verwendet werden kann. Bei verwendung von Python mit Anaconda kann es zu problemen kommen.

# Ordnerstruktur:
Toplevel:
==========
requirements, readme und main.py

Source:
=========
Implementierung der Logik für die Simulation.

Configs:
=========
Konfiguration der Spiele.

Tools:
========
Nützliche Skripte um Parameter für die Simulation zu finden und die Güte zu überprüfen.

load_profile_converter:
=========================
Ordner mit einem Skript welches die Standardlastprofile aus der Excel Tabelle extrahiert und aus 15 Minuten Monatslisten
24 Stunden Listen erzeugt und diese auf Sinnvolle Werte skaliert.

load_profiles:
===============
Die verschiedenen Lastprofile, welche in der Simulation verwendet werden können.
